

import pathlib
from typing import Set
from string import punctuation, whitespace

_STOPWORDS = None

def _load_stopwords() -> Set[str]:

    current_dir = pathlib.Path(__file__).parent
    path_to_file = current_dir / "stopwords.txt"
    with open(path_to_file, encoding="utf-8") as f:
        return set(f.read().splitlines())

def get_stopwords() -> Set[str]:
    global _STOPWORDS
    if _STOPWORDS is None:
        _STOPWORDS = _load_stopwords()
    return _STOPWORDS

def filter_stopwords(words: list[str]) -> list[str]:
    stopwords = get_stopwords()
    result = []
    for word in words:
        if not word:
            continue
        if word.lower() in stopwords:
            continue
        result.append(word)
    return result

def clean_words(words: list[str]) -> list[str]:
    return [word.strip(punctuation + whitespace + "—«»…") for word in words]