# cli/__init__.py

import pathlib
import json
from time import localtime, strftime
from typing import Literal, Annotated, Any

import typer

import python_kt_1.use_cases as use_cases
from .parse_params import get_files_from_path_arguments
from .renderer import display_stats

app = typer.Typer()


def _handle_output_file(output_path: pathlib.Path, data: Any) -> None:
    """
    Запись данных в JSON-файл с обработкой существующего файла.
    data может быть словарём (stats) или списком (top_words).
    """
    if not output_path.exists():
        with output_path.open('w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"Данные записаны в {output_path}")
        return

    while True:
        action = input(
            f"Файл {output_path} уже существует. Выберите действие:\n"
            "[o] перезаписать, [a] дополнить (как массив), [n] указать новый путь: "
        ).strip().lower()
        if action in ('o', 'overwrite'):
            with output_path.open('w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            print(f"Данные перезаписаны в {output_path}")
            break
        elif action in ('a', 'append'):
            if output_path.stat().st_size == 0:
                existing = []
            else:
                with output_path.open('r', encoding='utf-8') as f:
                    try:
                        existing = json.load(f)
                    except json.JSONDecodeError:
                        print("Файл повреждён, будет перезаписан.")
                        with output_path.open('w', encoding='utf-8') as fw:
                            json.dump(data, fw, ensure_ascii=False, indent=2)
                        break
            if isinstance(existing, list):
                existing.append(data)
            else:
                existing = [existing, data]
            with output_path.open('w', encoding='utf-8') as f:
                json.dump(existing, f, ensure_ascii=False, indent=2)
            print(f"Данные добавлены в {output_path}")
            break
        elif action in ('n', 'new path'):
            new = input("Введите новый путь: ").strip()
            if not new:
                continue
            _handle_output_file(pathlib.Path(new), data)
            break
        else:
            print("Неверный ввод. Попробуйте снова.")


@app.command()
def stats(
    input: Annotated[
        pathlib.Path,
        typer.Argument(
            help="Путь к файлу для анализа", exists=True, readable=True, file_okay=True
        ),
    ],
    output: Annotated[
        pathlib.Path | None,
        typer.Option(
            "--output", "-o", help="Путь к файлу для сохранения отчета", writable=True
        ),
    ] = None,
    pos: Annotated[
        bool, typer.Option(help="Добавить к отчету анализ частей речи")
    ] = False,
):
    """Статистика по текстовому файлу."""
    text = input.read_text(encoding="utf-8")
    result = use_cases.stats(text, pos=pos)

    if output:
        _handle_output_file(output, result)
    else:
        display_stats(result)


@app.command()
def search(
    pattern: Annotated[str, typer.Argument(help="Строка или регулярное выражение")],
    input: Annotated[
        list[pathlib.Path],
        typer.Argument(
            help="Файл(ы) или директория для поиска", exists=True, readable=True
        ),
    ],
    regex: Annotated[
        bool, typer.Option(help="Искать по регулярному выражению")
    ] = False,
    rich: Annotated[
        bool, typer.Option(help="Использовать форматированный вывод")
    ] = False,
):
    """Текстовый поиск по файлам или директории."""
    try:
        files_paths = get_files_from_path_arguments(*input)
        results = []
        for path in files_paths:
            filename = str(path.resolve())
            result = use_cases.search(pattern, path, regex)
            results.append((filename, result))
        print(results)
    except Exception as exc:
        print(exc)


@app.command("word-cloud")
def word_cloud(
    input: Annotated[
        pathlib.Path,
        typer.Argument(help="Исходный текстовый файл", exists=True, readable=True),
    ],
    output: pathlib.Path | None = pathlib.Path("/") / f"{strftime('%H_%M_%S', localtime())}_output.png",
    preprocess_mode: Literal["basic", "stemming", "lemmatization"] = "stemming",
):
    """Построение облака важных слов."""
    text = input.read_text(encoding="utf-8")
    result = use_cases.word_cloud(text, preprocess_mode)
    print(result)


@app.command(name="top-words")
def top_words(
    input: Annotated[
        pathlib.Path,
        typer.Argument(help="Исходный текстовый файл", exists=True, readable=True),
    ],
    output: pathlib.Path | None = None,
    normalize_mode: Literal["stemming", "lemmatization"] = "stemming",
    pos: list[str] = ["__all__"],
):
    """Подсчет топ-10 важных слов."""
    text = input.read_text(encoding="utf-8")
    result = use_cases.top_words(text, normalize_mode, pos)

    if output:
        _handle_output_file(output, result)
    else:
        for word, count in result:
            print(f"{word}: {count}")