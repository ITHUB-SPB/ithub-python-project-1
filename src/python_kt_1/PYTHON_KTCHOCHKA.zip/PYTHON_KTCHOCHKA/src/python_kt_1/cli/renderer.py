

from rich.console import Console
from rich.table import Table
from rich.box import ROUNDED, SIMPLE
from typing import Dict, Any

console = Console()

def display_stats(stats: Dict[str, Any]) -> None:
    """Вывод статистики текста в консоль с форматированием."""

    table = Table(title="Статистика текста", box=ROUNDED)
    table.add_column("Метрика", style="cyan")
    table.add_column("Значение", style="magenta")

    tokens = stats.get("tokens", {})
    if tokens:
        table.add_row("Абзацы", str(tokens.get("paragraphs", 0)))
        table.add_row("Предложения", str(tokens.get("sentences", 0)))
        table.add_row("Слова", str(tokens.get("words", 0)))

    symbols = stats.get("symbols", {})
    for key, value in symbols.items():
        if isinstance(value, dict):
            table.add_row(
                f"Символы: {key}",
                f"{value.get('quantity', 0)} ({value.get('percent', 0):.2f}%)"
            )
    console.print(table)


    if "pos" in stats and stats["pos"]:
        pos_table = Table(title="Статистика по частям речи", box=SIMPLE)
        pos_table.add_column("Часть речи", style="green")
        pos_table.add_column("Количество", style="yellow")
        for pos, count in sorted(stats["pos"].items(), key=lambda x: x[1], reverse=True):
            pos_table.add_row(pos, str(count))
        console.print(pos_table)
    else:
        console.print("[italic]Нет данных по частям речи[/italic]")