# use_cases/top_words.py

import re
from typing import List, Tuple
from collections import Counter

import nltk
from nltk.stem import SnowballStemmer
import spacy
from spacy.language import Language

from core.preprocess import get_stopwords

_nlp = None


def _get_spacy_model() -> Language:
    global _nlp
    if _nlp is None:
        try:
            _nlp = spacy.load("ru_core_news_sm")
        except OSError:
            raise ImportError(
                "Модель ru_core_news_sm не найдена. Установите: "
                "python -m spacy download ru_core_news_sm"
            )
    return _nlp


def top_words(
    text: str,
    normalize_mode: str = "stemming",
    pos: List[str] = ["__all__"],
    top_n: int = 10,
) -> List[Tuple[str, int]]:
    """
    Возвращает список самых частотных слов после предобработки.

    Args:
        text: исходный текст
        normalize_mode: "stemming" или "lemmatization"
        pos: список POS-тегов (например, ["NOUN", "ADJ"]). Если передан "__all__", фильтр не применяется.
        top_n: количество слов в результате

    Returns:
        Список кортежей (слово, частота)
    """
    stopwords = get_stopwords()
    use_spacy = (normalize_mode == "lemmatization") or (pos != ["__all__"])

    if use_spacy:
        nlp = _get_spacy_model()
        doc = nlp(text)
        words = []
        for token in doc:
            if token.is_punct or token.is_space or token.text.lower() in stopwords:
                continue
            if pos != ["__all__"] and token.pos_ not in pos:
                continue
            if normalize_mode == "lemmatization":
                word = token.lemma_.lower()
            else:  
                word = token.text.lower()
            words.append(word)

   
        if normalize_mode == "stemming" and pos != ["__all__"]:
            stemmer = SnowballStemmer("russian")
            words = [stemmer.stem(w) for w in words]

        counter = Counter(words)
        return counter.most_common(top_n)

    else:

        tokens = re.findall(r'\b\w+\b', text.lower())
        tokens = [t for t in tokens if t not in stopwords]
        stemmer = SnowballStemmer("russian")
        tokens = [stemmer.stem(t) for t in tokens]
        counter = Counter(tokens)
        return counter.most_common(top_n)